#include "SeqList.h"
#include<iostream>
#include<stdio.h>
using namespace std;
template<class T, int MaxSize>
SeqList<T,MaxSize>::SeqList()
{
}
template<class T, int MaxSize>
SeqList<T, MaxSize>::~SeqList()
{
}
template<class T, int MaxSize>
SeqList<T, MaxSize>::SeqList(T a[], int n)
{
	int i;
	if (n > MaxSize || n < 0)
	{
		cout << "�Ƿ����룡" << endl;
		exit(1);
	}
	for (i = 0; i < n; i++)
	{
		data[i] = a[i];
		length++;
	}
}
template<class T, int MaxSize>
int SeqList<T, MaxSize>::ListLength()
{
	return length;
}
template<class T, int MaxSize>
T SeqList<T, MaxSize>::Get(int pos)
{
	if (pos<0 || pos>MaxSize)
	{
		cout << "�Ƿ����룡" << endl;
		exit(1);
	}
	reutrn data[pos-1];
}
template<class T, int MaxSize>
int SeqList<T, MaxSize>::Locate(T item)
{
	int i ;
	for (i = 0; i < length; i++)
	{
		if (data[i] == item)
			return i + 1;
		return 0;
	}
}
template<class T, int MaxSize>
void SeqList<T, MaxSize>::PrintSeqList()
{
	int i;
	for (i = 0; i < length; i++)
	{
		cout << data[i] << endl;
		i++;
	}

}
template<class T, int MaxSize>
void SeqList<T, MaxSize>::Insert(int i, T item)
{
	if (length >= MaxSize)
		cout << "�����" << endl;
	if (i<1 || i>length + 1)
		cout << "����λ�÷Ƿ���" << endl;
	int j;
	for (j = length - 1; j > i - 1; j--)
		data[j + 1] = data[j];
	length = length + 1;
}
template<class T, int MaxSize>
T SeqList<T, MaxSize>::Detele(int i)
{
	if (i<0 || i>length)
	{
		cout << "λ�÷Ƿ���" << endl;
		exit(1);
	}
	int j;
	int x = data[i];
	for (j = i; j < length; j++)
		data[i] = data[i - 1];
	return  i;
}
template<class T, int MaxSize>
void SeqList<T, MaxSize>::sort()
{
	int i, j;
	for (i = 0; i < length-1; i++)
	{
		for (j = i; j = length - i - 1; j++)
		{
			if (data[j + 1] < data[i])
			{
				int tmp;
				tmp = data[j+ 1];
				data[j + 1] = data[j];
				data[j] = data[j + 1];
			}
		}
 }
}
//**********************************************
//**********************************************