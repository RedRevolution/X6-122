#pragma once
#ifndef SEQI.TST_H
#define SEQLTST_H
template<class T,int MaxSize>
class SeqList
{
	T date[MaxSize];
	int length;
public:
	SeqList();
	SeqList(T a[], int n);
	int ListLength();
	T Get(int pos);
	int Locate(T item);
	void PrintSeqList();
	void Insert(int i, T item);
	T Detele(int i);
	void sort();
	~SeqList();
};
#endif